package hms.Models;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "available", schema = "Hotels")
public class Available {
	
	@Id
	private String avlRoomDate;
	private String hname;
	private int quantity;
	
	
	Available(){
		System.out.println("default available constractor");
	}
	public Available(String hname, int quantity, String avlRoomDate) {
		
		this.hname = hname;
		this.quantity = quantity;
		this.avlRoomDate = avlRoomDate;
	}
	public String getHname() {
		return hname;
	}
	public void setHname(String hname) {
		this.hname = hname;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getAvlRoomDate() {
		return avlRoomDate;
	}
	public void setAvlRoomDate(String avlRoomDate) {
		this.avlRoomDate = avlRoomDate;
	}
	@Override
	public String toString() {
		return "Available [hname=" + hname + ", quantity=" + quantity + ", avlRoomDate=" + avlRoomDate + "]";
	}
	

}
