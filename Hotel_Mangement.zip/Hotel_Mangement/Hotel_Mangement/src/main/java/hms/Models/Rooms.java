package hms.Models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "rooms", schema = "Hotels")
public class Rooms {
	@Id
	private int Roomid;
	private String Rooms;
	private int Quantity;
	private int Price;
	
	Rooms(){
		System.out.println("room default constractor");
	}
	
	public Rooms(int roomId, String rooms, int quantity, int price) {
		
		Roomid = roomId;
		Rooms = rooms;
		Quantity = quantity;
		Price = price;
	}
	public int getRoomId() {
		return Roomid;
	}
	public void setRoomId(int roomId) {
		Roomid = roomId;
	}
	public String getRooms() {
		return Rooms;
	}
	public void setRooms(String rooms) {
		Rooms = rooms;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	@Override
	public String toString() {
		return "Rooms [RoomId=" + Roomid + ", Rooms=" + Rooms + ", Quantity=" + Quantity + ", Price=" + Price + "]";
	}
	
	

}
