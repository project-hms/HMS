package hms.Models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name = "booking", schema = "Hotels")
public class Booking {
	
	@Id
	private int Userid;
	private String Username;
	private String Ucity;
	private String Uhname;
	private  int Uhno;
	
	Booking(){
		System.out.println("default booking constructor");
	}
	
	public Booking(int userid, String username, String ucity, String uhname, int uhno) {
	
		Userid = userid;
		Username = username;
		Ucity = ucity;
		Uhname = uhname;
		Uhno = uhno;
	}
	public int getUserId() {
		return Userid;
	}
	public void setUserId(int userid) {
		Userid = userid;
	}
	public String getUsername() {
		return Username;
	}
	public void setUserName(String username) {
		Username = username;
	}
	public String getUcity() {
		return Ucity;
	}
	public void setUcity(String ucity) {
		Ucity = ucity;
	}
	public String getUhname() {
		return Uhname;
	}
	public void setUhname(String uhname) {
		Uhname = uhname;
	}
	public int getUhno() {
		return Uhno;
	}
	public void setUhno(int uhno) {
		Uhno = uhno;
	}
	@Override
	public String toString() {
		return "Booking [UserId=" + Userid + ", UserName=" + Username + ", Ucity=" + Ucity + ", Uhname=" + Uhname
				+ ", Uhno=" + Uhno + "]";
	}
	

}
