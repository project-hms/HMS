package hms.Models;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name ="customer", schema = "hotels" )
public class Customer {
	@Id
	private String Name;
	private String Email;
	private int Contact;
	private int Roomno;
	private int Price;
	

	Customer(){
		System.out.println("default constractor created");
	}
	public Customer(String name, String email, int contact, int roomno, int price) {
		
		Name = name;
		Email = email;
		Contact = contact;
		Roomno = roomno;
		Price = price;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public int getContact() {
		return Contact;
	}
	public void setContact(int contact) {
		Contact = contact;
	}
	public int getRoomNo() {
		return Roomno;
	}
	public void setRoomNo(int roomno) {
		Roomno = roomno;
	}
	public int getPrice() {
		return Price;
	}
	public void setPrice(int price) {
		Price = price;
	}
	@Override
	public String toString() {
		return "Customer [Name=" + Name + ", Email=" + Email + ", Contact=" + Contact + ", RoomNo=" + Roomno
				+ ", Price=" + Price + "]";
	}
}