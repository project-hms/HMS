package hms.Models;

public class CResult {
	
	private int status;
	private Customer content; // will have Customer details of inserted, updated, deleted
	private String reason;
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Customer getContent() {
		return content;
	}
	public void setContent(Customer content) {
		this.content = content;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public CResult() {
		// TODO Auto-generated constructor stub
	}
	public CResult(int status, Customer content, String reason) {

		this.status = status;
		this.content = content;
		this.reason = reason;
	}
	
	
	
	
	

}
