package hms.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import hms.Models.Available;
import hms.Models.Booking;
import hms.Models.Customer;
import hms.Models.Rooms;
import hms.Service.Service_Implementation;


@RestController
public class HMSController {
	
	    @Autowired
		private Service_Implementation sf;
		
		
		@GetMapping("/abc")
		public String f1()
		
		{
			return "who asked us to be optimistic";
		}
		
		@GetMapping("/gad")
		
		public List<Customer> getAllDetails(){
			return sf.getAllDetails();
		}
		
		@GetMapping("/gbd")
		public Optional<Booking> getBookingDetails(int Userid){
			return sf.getBookingDetails(Userid);
		}
		
        @GetMapping("/grd")
		
		public List<Rooms> getRoomDetails(){
			return sf.getRoomDetails();
		}
        
        
        @GetMapping("/gaaa")
		
		public List<Available> getAvailableDetails(){
			return sf.getAvailableDetails();
		}
		

	}


