package hms.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hms.DAO.AvailableRepo;
import hms.DAO.BookingRepo;
import hms.DAO.HMS_Repository;
import hms.DAO.RoomRepo;
import hms.Models.Available;
import hms.Models.Booking;
import hms.Models.CResult;
import hms.Models.Customer;
import hms.Models.Rooms;


@Service
public class Service_Implementation implements ServiceInterface {
	
	@Autowired
	private HMS_Repository hr;
	
	

	@Override
	public CResult getCustomerDetails(String Name) {
		CResult c1 =new CResult(0, null, "failed due to user");
		Optional<Customer> c = hr.findById(Name);
		if(c.isPresent())
		{
			Customer x = c.get();
			c1.setReason("success");
			c1.setStatus(1);
			c1.setContent(x);
		}
		else
			System.out.println("did not get the object");	
		
		
		return c1;
	}


	@Override
	public List<Customer> getAllDetails() {
		
		return hr.findAll();
		
	}

	@Autowired
	private RoomRepo rr;
	@Override
	public List<Rooms> getRoomDetails() {
		// TODO Auto-generated method stub
		return rr.findAll();
	}

	@Autowired
	private BookingRepo br;
	@Override
	public Optional<Booking> getBookingDetails(int UserId) {
		// TODO Auto-generated method stub
		return br.findById(UserId);
	}
	
	@Autowired
	private AvailableRepo ar;
	@Override
	public List<Available> getAvailableDetails() {
		// TODO Auto-generated method stub
		return ar.findAll();
	}



}