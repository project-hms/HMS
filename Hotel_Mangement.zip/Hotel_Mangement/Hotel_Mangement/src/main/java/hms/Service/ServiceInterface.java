package hms.Service;

import java.util.List;
import java.util.Optional;

import hms.Models.Available;
import hms.Models.Booking;
import hms.Models.CResult;
import hms.Models.Customer;
import hms.Models.Rooms;

public interface ServiceInterface {
	
	List<Rooms> getRoomDetails();
	
	Optional<Booking> getBookingDetails(int Userid);
	
	CResult getCustomerDetails(String name);
	
	List<Available> getAvailableDetails();

	List<Customer> getAllDetails();
}