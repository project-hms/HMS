package hms.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import hms.Models.Available;

public interface AvailableRepo extends JpaRepository<Available,String> {

}
