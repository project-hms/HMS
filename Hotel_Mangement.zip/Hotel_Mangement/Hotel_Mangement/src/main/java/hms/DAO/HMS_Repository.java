package hms.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hms.Models.Customer;

@Repository
public interface HMS_Repository extends JpaRepository<Customer,String> {

}
