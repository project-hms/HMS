package hms.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import hms.Models.Rooms;

@Repository
public interface RoomRepo extends JpaRepository<Rooms,String> {

}
