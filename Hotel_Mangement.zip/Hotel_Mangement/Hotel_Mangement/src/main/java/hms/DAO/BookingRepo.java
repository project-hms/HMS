package hms.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import hms.Models.Booking;

public interface BookingRepo extends JpaRepository<Booking,Integer> {

}
